const HTML = document.querySelector(".skillone");
const progress90 = document.querySelector(".container1");

const CSS = document.querySelector(".skilltwo");
const progress80 = document.querySelector(".container2");

const JS = document.querySelector(".skillthree");
const progress70 = document.querySelector(".container3");

const Creative = document.querySelector(".skillfour");
const progress85 = document.querySelector(".container4");

const aboutSec = document.querySelector("#About")
const projectsSec = document.querySelector("#projects")
const skillsSec = document.querySelector("#skills")
const contactSec = document.querySelector("#contact")
const clientHeight = document.documentElement.clientHeight;
document.addEventListener("scroll", function() {
  
  const aboutPos = aboutSec.getBoundingClientRect().top
  const projectsPos = projectsSec.getBoundingClientRect.top
  const skillsPos = skillsSec.getBoundingClientRect.top
  console.log(aboutPos,clientHeight)
  const contactPos = contactSec.getBoundingClientRect.top
  if(clientHeight>aboutPos&&aboutPos>-1000){
   aboutSec.style.display="flex"
  }
})
HTML.addEventListener("mouseover", function() {
  progress90.style.display = "block";
});
HTML.addEventListener("mouseout", function() {
  progress90.style.display = "none";
});

CSS.addEventListener("mouseover", function() {
  progress80.style.display = "block";
});
CSS.addEventListener("mouseout", function() {
  progress80.style.display = "none";
});
Creative;
JS.addEventListener("mouseover", function() {
  progress70.style.display = "block";
});
JS.addEventListener("mouseout", function() {
  progress70.style.display = "none";
});

Creative.addEventListener("mouseover", function() {
  progress85.style.display = "block";
});
Creative.addEventListener("mouseout", function() {
  progress85.style.display = "none";
});
